'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createApp } = require('../server');

async function start() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'momentum-'));
  const server = createApp({ dataFile: path.join(dir, 'db.json'), log: () => {} });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  let cookie = '';
  const call = async (method, url, body) => {
    const res = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(cookie ? { cookie } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const set = res.headers.get('set-cookie');
    if (set) cookie = set.split(';')[0];
    const text = await res.text();
    return { status: res.status, data: text && res.headers.get('content-type')?.includes('json') ? JSON.parse(text) : text };
  };
  return { server, call, close: () => server.close() };
}

test('serves the front end', async () => {
  const { call, close } = await start();
  for (const p of ['/', '/app.js', '/styles.css']) assert.equal((await call('GET', p)).status, 200, p);
  close();
});

test('register, tasks and habits round trip', async () => {
  const { call, close } = await start();
  assert.equal((await call('GET', '/api/tasks')).status, 401);
  assert.equal((await call('POST', '/api/auth/register', { email: 'a@b.co', password: 'password123' })).status, 201);

  const t = await call('POST', '/api/tasks', { title: 'Write tests', priority: 'high', due: '2026-11-05' });
  assert.equal(t.status, 201);
  const id = t.data.task.id;
  assert.equal((await call('PATCH', `/api/tasks/${id}`, { done: true })).data.task.done, true);
  assert.equal((await call('POST', '/api/tasks', { title: '' })).status, 400);

  const h = await call('POST', '/api/habits', { title: 'Read' });
  const hid = h.data.habit.id;
  assert.equal((await call('PUT', `/api/habits/${hid}/checkins/2026-11-03`)).status, 204);
  assert.deepEqual((await call('GET', '/api/habits')).data.habits[0].days, ['2026-11-03']);

  assert.equal((await call('DELETE', `/api/tasks/${id}`)).status, 204);
  assert.equal((await call('GET', '/api/tasks')).data.tasks.length, 0);
  close();
});

test('wrong password is rejected', async () => {
  const { call, close } = await start();
  await call('POST', '/api/auth/register', { email: 'a@b.co', password: 'password123' });
  assert.equal((await call('POST', '/api/auth/login', { email: 'a@b.co', password: 'nope-nope-nope' })).status, 401);
  close();
});
