# Momentum

A small, self-hosted app for **tasks**, **daily habits** and a **calendar**, with user accounts.
No frameworks and no dependencies: just Node.js built-ins and plain JavaScript.

## Features

- **Tasks** with priority (low / medium / high) and optional due dates, plus overdue highlighting
- **Habits** with a 7-day check-in strip and running streaks
- **Calendar** month view showing tasks by due date, with quick-add for any day
- **Accounts**: register, sign in, sign out and password reset
- Light and dark themes that follow your system setting
- Keyboard and screen-reader friendly

## Quick start

You need [Node.js](https://nodejs.org) 18.11 or newer.

```bash
git clone https://github.com/<your-username>/momentum.git
cd momentum
npm start
```

Then open **http://localhost:3000**.

There is nothing to `npm install`.

### Changing the port

```bash
# macOS / Linux
PORT=3001 npm start

# Windows (cmd)
set PORT=3001 && npm start

# Windows (PowerShell)
$env:PORT=3001; npm start
```

## Project layout

```
momentum/
├── server.js        # HTTP server, API and auth
├── package.json
├── public/          # Front end, served as static files
│   ├── index.html
│   ├── app.js
│   └── styles.css
├── test/            # Tests (node --test)
└── data/            # Created on first run; holds db.json (git-ignored)
```

> The server only serves files from `public/`. If you see `{"error":"Not found."}`,
> make sure `index.html`, `app.js` and `styles.css` are inside that folder.

## Configuration

| Variable   | Default     | Purpose                                              |
| ---------- | ----------- | ---------------------------------------------------- |
| `PORT`     | `3000`      | Port to listen on                                    |
| `HOST`     | `127.0.0.1` | Interface to bind. Use `0.0.0.0` to allow LAN access |
| `BASE_URL` | request host | Base used in password-reset links                   |

## Password reset

There is no email service built in. When someone requests a reset, the link is
**printed in the terminal** where the server is running. Copy it into your browser.
Links expire after one hour.

## Data and security notes

- Data is stored in `data/db.json`. Back this file up if it matters to you.
- Passwords are hashed with scrypt, and sessions use HttpOnly cookies.
- Sign-in attempts are rate limited per IP address.
- This app is built for personal or small-team use on a trusted machine. If you
  expose it to the internet, put it behind HTTPS (for example a reverse proxy)
  and consider moving from a JSON file to a real database.

## API overview

All routes are under `/api` and, except for auth, require a signed-in session.

| Method | Route | Description |
| ------ | ----- | ----------- |
| POST | `/auth/register`, `/auth/login`, `/auth/logout` | Account and session |
| POST | `/auth/forgot`, `/auth/reset` | Password reset |
| GET | `/auth/me` | Current user |
| GET, POST | `/tasks` | List or create tasks |
| PATCH, DELETE | `/tasks/:id` | Update or delete a task |
| GET, POST | `/habits` | List or create habits |
| DELETE | `/habits/:id` | Delete a habit |
| PUT, DELETE | `/habits/:id/checkins/:YYYY-MM-DD` | Add or remove a check-in |

## Development

```bash
npm run dev    # restart automatically on changes
npm test       # run the test suite
```

## License

MIT. See [LICENSE](LICENSE).
